Rails.application.routes.draw do

  get 'homes/top'
  resources :books
  get 'books' => "books#new", as:"index_books"
  root to: "homes#top"
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
end
